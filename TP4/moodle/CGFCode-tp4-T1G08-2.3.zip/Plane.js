function Plane(scene, nrDivs)
{
    CGFobject.call(this, scene);

    nrDivs = typeof nrDivs !== 'undefined' ? nrDivs : 1;

    this.nrDivs = nrDivs;
    this.patchLength = 1.0 / nrDivs;
    this.initBuffers();
};

Plane.prototype = Object.create(CGFobject.prototype);
Plane.prototype.constructor = Plane;

Plane.prototype.initBuffers = function ()
{
    this.vertices = [];
    this.normals = [];

    var yCoord = 0.5;

    for (var j = 0; j <= this.nrDivs; j++)
    {
        var xCoord = -0.5;

        for (var i = 0; i <= this.nrDivs; i++)
        {
            this.vertices.push(xCoord, yCoord, 0);
            this.normals.push(0, 0, 1);

            xCoord += this.patchLength;
        }

        yCoord -= this.patchLength;
    }

    this.indices = [];

    var ind = 0;

    for (var j = 0; j < this.nrDivs; j++)
    {
        for (var i = 0; i <= this.nrDivs; i++)
        {
            this.indices.push(ind);
            this.indices.push(ind + this.nrDivs + 1);

            ind++;
        }

        if (j + 1 < this.nrDivs)
        {
            this.indices.push(ind + this.nrDivs);
            this.indices.push(ind);
        }
    }

    this.primitiveType = this.scene.gl.TRIANGLE_STRIP;
    this.initGLBuffers();
};