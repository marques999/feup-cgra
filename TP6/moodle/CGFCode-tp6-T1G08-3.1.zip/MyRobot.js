function MyRobot(scene)
{
	CGFobject.call(this, scene);

	this.robotAngle = Math.PI;
	this.robotIncrement = Math.PI / 12;
	this.robotX = 8.5;
	this.robotY = 0.0;
	this.robotZ = 8.0;

	this.robotAppearance = new CGFappearance(this.scene);
	this.robotAppearance.setAmbient(0.5, 0.5, 0.5, 1.0);
	this.robotAppearance.setDiffuse(0.9, 0.4, 0.0, 1.0);
	this.robotAppearance.setSpecular(0.6, 0.6, 0.6, 1.0);
	this.robotAppearance.setShininess(60);

	this.initBuffers();
};

MyRobot.prototype = Object.create(CGFobject.prototype);
MyRobot.prototype.constructor = MyRobot;

MyRobot.prototype.initBuffers = function()
{
	this.vertices = 
	[
		0.5, 0.3, 0.0,
		-0.5, 0.3, 0.0,
		0.0, 0.3, 2.0
	];

	this.indices = 
	[ 
		0, 1, 2,
		1, 0, 2
	];

	this.normals = 
	[ 
		0, 0, 1,
		0, 0, 1,
		0, 0, 1
	];

	this.primitiveType = this.scene.gl.TRIANGLES;
	this.initGLBuffers();
};

MyRobot.prototype.move = function(dx, dz)
{
	if (this.robotX + dx >= 1.0 && this.robotX + dx <= 15.0)
	{
		this.robotX += dx;
	}

	if (this.robotZ + dz >= 1.0 && this.robotZ + dz <= 15.0)
	{
		this.robotZ += dz;
	}
}

MyRobot.prototype.moveForward = function()
{
	this.move(Math.sin(this.robotAngle), Math.cos(this.robotAngle));
}

MyRobot.prototype.moveBackward = function()
{
	this.move(-Math.sin(this.robotAngle), -Math.cos(this.robotAngle));
}

MyRobot.prototype.rotateLeft = function()
{
	this.robotAngle += this.robotIncrement;
};

MyRobot.prototype.rotateRight = function()
{
	this.robotAngle -= this.robotIncrement;
}

MyRobot.prototype.draw = function()
{
	this.scene.translate(this.robotX, this.robotY, this.robotZ);
	this.scene.rotate(this.robotAngle, 0, 1, 0);
	this.robotAppearance.apply();
};