function MyRobot(scene)
{
	CGFobject.call(this, scene);

	this.robotX = 8.5;
	this.robotY = 0.0;
	this.robotZ = 8.0;
	this.robotAngle = 0.0;
	this.robotScale = 1.0;
	this.robotIncrement = Math.PI / 24;
	
	this.goForward = 0;
	this.goBackward = 0;
	this.rotateLeft = 0;
	this.rotateRight = 0;

	this.robotAppearance = new CGFappearance(this.scene);
	this.robotAppearance.setAmbient(0.5, 0.5, 0.5, 1.0);
	this.robotAppearance.setDiffuse(0.9, 0.9, 0.9, 1.0);
	this.robotAppearance.setSpecular(0.6, 0.6, 0.6, 1.0);
	this.robotAppearance.setShininess(60);

	this.robotBody = new MyCylinder(this.scene, 24, 24, 0.0, 1.0, 0.5, 1.0);
	this.robotBody.initBuffers();
	this.robotHead = new MyLamp(this.scene, 24, 24, 0.0, 1.0, 0.0, 0.5);
	this.robotHead.initBuffers();
	this.robotLeftArm = new MyRobotArm(this.scene);
	this.robotLeftArm.initBuffers();
	this.robotRightArm = new MyRobotArm(this.scene);
	this.robotRightArm.initBuffers();
	this.robotLeftWheel = new MyRobotWheel(this.scene);
	this.robotLeftWheel.initBuffers();
	this.robotRightWheel = new MyRobotWheel(this.scene);
	this.robotRightWheel.initBuffers();
};

MyRobot.prototype = Object.create(CGFobject.prototype);
MyRobot.prototype.constructor = MyRobot;

MyRobot.prototype.setScale = function(amt)
{
	this.robotScale = amt;
};

MyRobot.prototype.setTexture = function(str)
{
	this.robotAppearance.loadTexture(str);
};

MyRobot.prototype.move = function(dx, dz)
{
	if (this.robotX + dx >= 0.5 && this.robotX + dx <= 15.0)
	{
		this.robotX += dx;
	}

	if (this.robotZ + dz >= 0.5 && this.robotZ + dz <= 15.0)
	{
		this.robotZ += dz;
	}
};

MyRobot.prototype.moveForward = function()
{
	this.move(-Math.sin(this.robotAngle) / 4, -Math.cos(this.robotAngle) / 4);
};

MyRobot.prototype.moveBackward = function()
{
	this.move(Math.sin(this.robotAngle) / 4, Math.cos(this.robotAngle) / 4);
};

MyRobot.prototype.rotate = function(right)
{
	if (right)
	{
		this.robotAngle -= this.robotIncrement;
	}
	else
	{
		this.robotAngle += this.robotIncrement;
	}
};

MyRobot.prototype.update = function()
{
	if (this.goForward)
	{
		this.moveForward();
	}

	if (this.goBackward)
	{
		this.moveBackward();
	}

	if (this.rotateLeft)
	{
		this.rotate(false);
	}

	if (this.rotateRight)
	{
		this.rotate(true);
	}
}

MyRobot.prototype.display = function()
{
	// Robot
	this.scene.translate(this.robotX, this.robotY, this.robotZ);
	this.scene.rotate(this.robotAngle, 0, 1, 0);
	this.scene.scale(this.robotScale, this.robotScale, this.robotScale);

	// Robot Body
	this.scene.pushMatrix();
	this.scene.translate(0.0, 0.25, 0.0);
	this.scene.scale(0.7, 1.25, 0.7);
	this.robotAppearance.apply();
	this.robotBody.display();
	this.scene.popMatrix();

	// Robot Head
	this.scene.pushMatrix();
	this.scene.translate(0.0, 1.5, 0.0);
	this.scene.scale(0.7, 0.6, 0.7);
	this.robotAppearance.apply();
	this.robotHead.display(),
	this.scene.popMatrix();

	// Robot Left Wheel
	this.scene.pushMatrix();
	this.scene.translate(-0.9, 0.4, 0.0);
	this.scene.scale(1.0, 0.4, 0.4);
	this.scene.rotate(Math.PI / 2, 0, 1, 0);
	this.robotLeftWheel.display();
	this.scene.popMatrix();

	// Robot Right Wheel
	this.scene.pushMatrix();
	this.scene.translate(0.9, 0.4, 0.0);
	this.scene.scale(1.0, 0.4, 0.4);
	this.scene.rotate(Math.PI / 2, 0, -1, 0);
	this.robotRightWheel.display();
	this.scene.popMatrix();

	// Robot Left Arm
	this.scene.pushMatrix();
	this.scene.translate(-0.75, 1.5, 0.0);
	this.robotLeftArm.display();
	this.scene.popMatrix();

	// Robot Right Arm
	this.scene.pushMatrix();
	this.scene.translate(0.75, 1.5, 0.0);
	this.robotRightArm.display();
	this.scene.popMatrix();
};