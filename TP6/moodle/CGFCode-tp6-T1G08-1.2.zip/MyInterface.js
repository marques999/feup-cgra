function MyInterface() 
{
	CGFinterface.call(this);
};

MyInterface.prototype = Object.create(CGFinterface.prototype);
MyInterface.prototype.constructor = MyInterface;

MyInterface.prototype.init = function(application) 
{
	CGFinterface.prototype.init.call(this, application);
	
	this.gui = new dat.GUI();
	this.gui.add(this.scene, 'doSomething');	

	var group = this.gui.addFolder("Options");
	
	group.open();
	group.add(this.scene, 'option1');
	group.add(this.scene, 'option2');
	
	this.gui.add(this.scene, 'speed', -5, 5);

	return true;
};

MyInterface.prototype.processKeyboard = function(event) 
{
	CGFinterface.prototype.processKeyboard.call(this, event);

	var keyCode = event.keyCode || event.which;
	
	switch (keyCode)
	{
		case 87: case 119:
			console.log("INFORMATION: key 'W' pressed...");
			break;
		case 83: case 115:
			console.log("INFORMATION: key 'S' pressed...");
			break;
		case 65: case 97:
			console.log("INFORMATION: key 'A' pressed...");
			break;
		case 58: case 100:
			console.log("INFORMATION: key 'D' pressed...");
			break;
	};
};