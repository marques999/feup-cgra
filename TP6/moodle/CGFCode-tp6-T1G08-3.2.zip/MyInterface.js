function MyInterface()
{
	CGFinterface.call(this);
};

MyInterface.prototype = Object.create(CGFinterface.prototype);
MyInterface.prototype.constructor = MyInterface;

MyInterface.prototype.init = function(application)
{
	CGFinterface.prototype.init.call(this, application);

	this.gui = new dat.GUI();
	this.gui.add(this.scene, 'pauseAirplane');
	this.gui.add(this.scene, 'pauseClock');
	this.gui.add(this.scene, 'pauseScene');

	var groupLights = this.gui.addFolder("Lights");

	groupLights.open();
	groupLights.add(this.scene, 'backgroundLight');
	groupLights.add(this.scene, 'boardLight');
	groupLights.add(this.scene, 'slidesLight');
	groupLights.add(this.scene, 'windowLight');

	var groupScene = this.gui.addFolder("Scene");

	groupScene.open();
	groupScene.add(this.scene, 'drawAirplane');
	groupScene.add(this.scene, 'drawBall');
	groupScene.add(this.scene, 'drawBoard');
	groupScene.add(this.scene, 'drawChairs');
	groupScene.add(this.scene, 'drawColumns');
	groupScene.add(this.scene, 'drawClock');
	groupScene.add(this.scene, 'drawRobot');
	groupScene.add(this.scene, 'drawSlides');
	groupScene.add(this.scene, 'drawTables');
	groupScene.add(this.scene, 'updateInterval', 10, 60);

	return true;
};

MyInterface.prototype.processKeyboard = function(event)
{
	CGFinterface.prototype.processKeyboard.call(this, event);

	switch (event.keyCode || event.which)
	{
		case 87: case 119:
			this.scene.robot.moveForward();
			break;
		case 83: case 115:
			this.scene.robot.moveBackward();
			break;
		case 65: case 97:
			this.scene.robot.rotateLeft();
			break;
		case 68: case 100:
			this.scene.robot.rotateRight();
			break;
	};
};